package com.antho.glow;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class cmd implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] arg) {
        if (commandSender instanceof Player p){
            if (arg.length==0){
                Audience player = Glow.get().adventure().player(p.getUniqueId());
                var mm = MiniMessage.miniMessage();
                Component parsed = mm.deserialize("<click:run_command:'/potatoclicker'>click 2 open potato click</click>");
                player.sendMessage(parsed);
            }
        }
        return true;
    }
}
