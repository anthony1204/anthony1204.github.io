package com.antho.glow;

import net.kyori.adventure.platform.bukkit.BukkitAudiences;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.checkerframework.checker.nullness.qual.NonNull;

public final class Glow extends JavaPlugin {
    private BukkitAudiences adventure;
    private Glow dis = this;
    public @NonNull BukkitAudiences adventure() {
        if(this.adventure == null) {
            throw new IllegalStateException("Tried to access Adventure when the plugin was disabled!");
        }
        return this.adventure;
    }
    @Override
    public void onEnable() {
        // Plugin startup logic
        getCommand("glow").setTabCompleter(new tab());
        getCommand("glow").setExecutor(new cmd());
        Bukkit.broadcastMessage("glow successfully enabled");
        this.adventure = BukkitAudiences.create(this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        if(this.adventure != null) {
            this.adventure.close();
            this.adventure = null;
        }
    }
    public static Glow get(){
        return get().dis;
    }
}
