package com.antho.glow;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class tab implements TabCompleter {
    @Override
    public List<String> onTabComplete(CommandSender commandSender, Command command, String s, String[] strings) {
        List<String> c = new ArrayList<>();
        c.add("run the command without arguments! you will be able to select from the chat.");
        return c;
    }
}
